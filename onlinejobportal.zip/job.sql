/*
SQLyog Community v12.02 (32 bit)
MySQL - 5.5.29 : Database - job
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`job` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `job`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`name`,`password`) values ('admin','admin');

/*Table structure for table `applyjob` */

DROP TABLE IF EXISTS `applyjob`;

CREATE TABLE `applyjob` (
  `username` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `file` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `applyjob` */

insert  into `applyjob`(`username`,`email`,`position`,`company`,`location`,`file`) values ('Psalmgajey','psalmgajey@gmail.com','Java ','VLSA TECH','Chennai','tweets.txt'),('Psalmgajey','psalmgajey@gmail.com','Java ','VLSA TECH','Chennai','tweets.txt'),('Psalmgajey','psalmgajey@gmail.com','Java Developer','DLK Tech','Chennai','barchart.txt'),('Psalmgajey','psalmgajey@gmail.com','Web Designer','DLK Tech','Trichy','ID2S.txt'),('Ramkumar','invalid.dg@gmail.com','Java Developer','DLK Tech','Chennai','Profiling.txt'),('Ramkumar','invalid.dg@gmail.com','Web Designer','DLK Tech','Trichy','Profiling.txt');

/*Table structure for table `dot` */

DROP TABLE IF EXISTS `dot`;

CREATE TABLE `dot` (
  `position` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `experience` varchar(100) DEFAULT NULL,
  `keyskill` text,
  `jobtype` varchar(100) DEFAULT NULL,
  `education` varchar(300) DEFAULT NULL,
  `interdate` varchar(100) DEFAULT NULL,
  `intertime` varchar(100) DEFAULT NULL,
  `contect` varchar(100) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `salary` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `dot` */

insert  into `dot`(`position`,`company`,`address`,`experience`,`keyskill`,`jobtype`,`education`,`interdate`,`intertime`,`contect`,`mobile`,`salary`) values ('.Net Developer','D&G Technologies','Chennai','0-2','* Good Communication Skills\r\n* Good Team Work\r\n* Jsp and Servlet','Part Time','MCA','03.12.2017','10 A.M to 01 P.M','Psalmgajey','9788862743','100000/yr');

/*Table structure for table `find` */

DROP TABLE IF EXISTS `find`;

CREATE TABLE `find` (
  `enterkey` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `find` */

insert  into `find`(`enterkey`,`location`) values ('java','chennai'),('java','Trichy'),('java','Mumbai'),('java','Bangalore'),('java','up'),('.Net','chennai'),('.Net','mumbai'),('php','chennai'),('mca','chennai'),('html','chennai');

/*Table structure for table `javadeveloper` */

DROP TABLE IF EXISTS `javadeveloper`;

CREATE TABLE `javadeveloper` (
  `position` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `experience` varchar(100) DEFAULT NULL,
  `keyskill` text,
  `jobtype` varchar(100) DEFAULT NULL,
  `education` varchar(300) DEFAULT NULL,
  `interdate` varchar(100) DEFAULT NULL,
  `intertime` varchar(100) DEFAULT NULL,
  `contect` varchar(100) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `salary` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `javadeveloper` */

insert  into `javadeveloper`(`position`,`company`,`address`,`experience`,`keyskill`,`jobtype`,`education`,`interdate`,`intertime`,`contect`,`mobile`,`salary`) values ('Java Developer','DLK Tech','Chennai','0-2','* Good Communication Skills\r\n* Good Team Work\r\n* Jsp and Servlet','Full Time','MCA','03.12.2017','10 A.M to 01 P.M','David','9788862743','100000/yr'),('Java Developer','D&G Technologies','Chennai','0-2','* Good Communication Skills\r\n* Good Team Work\r\n* Jsp and Servlet','Part Time','MCA','03.12.2017','10 A.M to 01 P.M','Psalmgajey','9788862743','100000/yr'),('.Net','DLK TECH','Trichy','0-2','Very importance for core java and advanced java concepts','Full Time','MCA','03.12.2017','10 A.M to 01 P.M','Psalmgajey','9940934119','100000/yr'),('Java ','VLSA TECH','Chennai','Fresher','Should have basic knowledge about java\r\nGood Communication Skills\r\n','Full Time and Permanent','MCA.,BCA.,IT','03.12.2017','10 A.M to 01 P.M','Psalmgajey','9788862743','20,000 a month'),('Java Trainer','REC Technologies','Chennai','0-2',' HTML, CSS, Javascript, JQuery.RDBMS: \r\n MySQL / OracleApplication Server: \r\n Tomcat, etc.IDE: Eclipse','Full Time and Permanent','CSC.,IT.,MCA','03.12.2017','10 A.M to 01 P.M','David','9940934119','20,000 a month'),('Web Designer','DLK Tech','Trichy','Fresher',' HTML, CSS, Javascript, JQuery.RDBMS: \r\n Good Communication Skill\r\n','Full Time and Permanent','MCA.,BCA.,IT','03.12.2017','10 A.M to 01 P.M','Bhuvana','9940934119','100000/yr'),('Java Trainer','REC Technologies','Chennai','Fresher','Good Communication \r\n\r\nJSP and Servlet\r\n\r\n','Full Time and Permanent','MCA.,BCA.,IT','03.12.2017','10 A.M to 01 P.M','Ganesan','9788862743','20,000 a month');

/*Table structure for table `jtrainer` */

DROP TABLE IF EXISTS `jtrainer`;

CREATE TABLE `jtrainer` (
  `position` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `experience` varchar(100) DEFAULT NULL,
  `keyskill` text,
  `jobtype` varchar(100) DEFAULT NULL,
  `education` varchar(300) DEFAULT NULL,
  `interdate` varchar(100) DEFAULT NULL,
  `intertime` varchar(100) DEFAULT NULL,
  `contect` varchar(100) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `salary` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `jtrainer` */

insert  into `jtrainer`(`position`,`company`,`address`,`experience`,`keyskill`,`jobtype`,`education`,`interdate`,`intertime`,`contect`,`mobile`,`salary`) values ('Java Trainer','D&G Technologies','Chennai','0-2','* Good Communication Skills\r\n* Good Team Work\r\n* Jsp and Servlet','Full Time','M.E','03.12.2017','10 A.M to 01 P.M','David','9940934119','100000/yr');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(70) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(40) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `exp` varchar(50) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `gender` varchar(33) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`id`,`fullname`,`address`,`email`,`mobile`,`country`,`exp`,`education`,`city`,`gender`,`username`,`password`) values (7,'Gajenthiran','Umbalapadi','psalmgajey@gmail.com','9788862743','India','Fresher','Mca','Papanasam','male','Psalmgajey','333'),(10,'Ganesan','Chennai','invalid.dg@gmail.com','9788862743','India','Fresher','BTech','Papanasam','male','Ramkumar','333');

/*Table structure for table `web` */

DROP TABLE IF EXISTS `web`;

CREATE TABLE `web` (
  `position` varchar(100) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `experience` varchar(100) DEFAULT NULL,
  `keyskill` text,
  `jobtype` varchar(100) DEFAULT NULL,
  `education` varchar(300) DEFAULT NULL,
  `interdate` varchar(100) DEFAULT NULL,
  `intertime` varchar(100) DEFAULT NULL,
  `contect` varchar(100) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `salary` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `web` */

insert  into `web`(`position`,`company`,`address`,`experience`,`keyskill`,`jobtype`,`education`,`interdate`,`intertime`,`contect`,`mobile`,`salary`) values ('Web Designer','D&G Technologies','Chennai','0-2','* Good Communication Skills\r\n* Good Team Work\r\n* Jsp and Servlet','Full Time','M.E','03.12.2017','10 A.M to 01 P.M','Psalmgajey','9940934119','100000/yr');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
